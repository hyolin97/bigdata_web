<!doctype html>
<html lang="en">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 </head>
 <body>
 <h3>요청정보</h3>
 <form method="GET" >
 <?php
 $person=$_GET["person"];
 $college=$_GET["college"];
 $age=$_GET["age"];
 $subject=$_GET["subject"];
 ?>
 name: <?php print " $person"; ?><br>
 dept:<?php
 print" $college"; ?><br>
 year:<?php print " $age"; ?><br>
 class:<?php print " $subject"; ?>
    
	
    
    </form>
    

  
 </body>
</html>
