<!doctype html>
<html lang="en">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 </head>
 <body>
 <form method="GET" action="2페이지.php">
 <?php
 $name=$_GET["name"];
 $college=$_GET["college"];
 $age=$_GET["age"];
 $subject=$GET["subject"];
 ?>
 성명: <?php print "name= $name"; ?><br>
 학과:<?php print college= $college; ?><br>
 학년:<?php print 학년= $age; ?><br>
 과목:<?php print 과목= $subject; ?>
    
	
    
    </form>
    

  
 </body>
</html>
