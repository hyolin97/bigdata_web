<!doctype html>
<html lang="en">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 </head>
 <body>
 <h3> 요청정보</h3>
 <form method="GET" >
  <?php
  $email=$GET_["email"];
  $tel=$GET_["tel"];
  ?>
 이메일: <?php print "$email";?> <br>
 전화번호:<?php print "$tel";?><br>
 
</form>
    
    

  
 </body>
</html>

