<!doctype html>
<html lang="en">
 <head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
 </head>
 <body>
  <form method="GET" ">
 <?php
 $name=$_GET["person"];
 $college=$_GET["college"];
 $age=$_GET["age"];
 $subject=$_GET["subject"];
 ?>
 성명: <?php print "$name";?><br>
 학과:<?php print "$college";?><br>
 학년:<?php print "$age";?></br>
 과목:<?php print "$subject";?><br>
      
 </body>
</html>