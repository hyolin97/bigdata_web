<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  
 </head>
 <body>
 <form method="get" >
 <h3>요청정보</h3>
 <?php 
 $sex=$_GET["sex"];
 $part=$_GET["part"];
 $age=$_GET["age"];
 $seminar=$_GET["seminar"];
 $satis=$_GET["satis"];
 $time=$GET["time"];
 ?>
 성별:<?php print "$sex";?><br>
 나이:<?php print "$age";?><br>
 관심분야:<?php print "$part";?>
 <br>
본 세미나의 주제는 만족스러운가?<?php print "$seminar";?><br>
본 세미나의 초청 강사는 만족스러운가?<?php print "$satis";?> <br>
본 세미나의 강의 시간은 적당한가? <?php print "$time";?><br>


    </form>


  
 </body>
</html>

